---
name: Cyber Neon Bartender
colors:
  surface: '#12131a'
  surface-dim: '#12131a'
  surface-bright: '#383940'
  surface-container-lowest: '#0c0e14'
  surface-container-low: '#1a1b22'
  surface-container: '#1e1f26'
  surface-container-high: '#282a31'
  surface-container-highest: '#33343c'
  on-surface: '#e2e1eb'
  on-surface-variant: '#bac9cd'
  inverse-surface: '#e2e1eb'
  inverse-on-surface: '#2f3037'
  outline: '#859397'
  outline-variant: '#3b494c'
  surface-tint: '#00daf5'
  primary: '#c2f4ff'
  on-primary: '#00363e'
  primary-container: '#22e3ff'
  on-primary-container: '#00616f'
  inverse-primary: '#006876'
  secondary: '#ffb0d0'
  on-secondary: '#63003c'
  secondary-container: '#ff43a9'
  on-secondary-container: '#570034'
  tertiary: '#ffe9bf'
  on-tertiary: '#3f2e00'
  tertiary-container: '#ffc736'
  on-tertiary-container: '#705400'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#a1efff'
  primary-fixed-dim: '#00daf5'
  on-primary-fixed: '#001f25'
  on-primary-fixed-variant: '#004e59'
  secondary-fixed: '#ffd8e6'
  secondary-fixed-dim: '#ffb0d0'
  on-secondary-fixed: '#3d0023'
  on-secondary-fixed-variant: '#8c0057'
  tertiary-fixed: '#ffdf9c'
  tertiary-fixed-dim: '#f5be2d'
  on-tertiary-fixed: '#251a00'
  on-tertiary-fixed-variant: '#5b4300'
  background: '#12131a'
  on-background: '#e2e1eb'
  surface-variant: '#33343c'
typography:
  headline-xl:
    fontFamily: Chakra Petch
    fontSize: 40px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: 0.02em
  headline-lg:
    fontFamily: Chakra Petch
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Chakra Petch
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Sora
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Sora
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  data-mono:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: '1.4'
    letterSpacing: 0.05em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '400'
    lineHeight: '1.0'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  gutter: 16px
  margin-mobile: 20px
  margin-desktop: 40px
  container-padding: 24px
---

## Brand & Style

This design system targets the modern, tech-savvy home mixologist who views cocktail making as both an art and a precise science. The brand personality is futuristic, high-tech, and nocturnally sophisticated. 

The visual style blends **Glassmorphism** with a **Cyberpunk-inspired Minimalist** aesthetic. It utilizes deep space blacks to create an infinite depth, punctuated by electric neon strikes that simulate light-emitting hardware interfaces. The atmosphere should evoke the feeling of a high-end, underground automated bar in a near-future metropolis—precise, clean, and vibrantly alive.

## Colors

The palette is anchored in a "Deep Space" near-black background to maximize the perceived luminance of the neon accents. 

- **Primary (Electric Cyan):** Used for primary actions, success states, and critical brand identifiers. It carries a glow effect to simulate light emission.
- **Secondary (Sparse Magenta):** Used as a "flavor" accent—perfect for highlights, special ingredients, or AI-driven suggestions.
- **Surface:** Glass-morphic layers use a highly transparent white tint with heavy background blur to maintain legibility without breaking the dark aesthetic.
- **Functional:** Grays are kept cool-toned to match the cyan temperature.

## Typography

The typographic hierarchy uses three distinct typefaces to separate intent:

1.  **Chakra Petch (Headers):** A square-cut, industrial font that feels like a digital readout or a futuristic stencil. Use for all high-level titles.
2.  **Sora (Body):** A modern sans-serif with a wide aperture and distinct geometry. It ensures high legibility for recipe steps and descriptions.
3.  **JetBrains Mono (Technical Data):** Used for ingredient measurements, ABV percentages, AI processing logs, and metadata. This reinforces the "AI Bartender" persona through a developer-centric aesthetic.

For mobile, `headline-xl` scales down to 32px to ensure no text wrapping issues on smaller displays.

## Layout & Spacing

The layout utilizes a **Fluid Grid** system that prioritizes vertical scanning for recipes and horizontal swiping for ingredient carousels.

- **Grid:** A 12-column grid for desktop and a 4-column grid for mobile.
- **Rhythm:** An 8px linear scale is used for all padding and margins. 
- **Density:** High-density technical areas (ingredient lists) contrast with low-density hero areas (cocktail imagery) to create visual "breathing room" amidst the neon intensity.
- **Breakpoints:** 
  - Mobile: < 600px
  - Tablet: 600px - 1024px
  - Desktop: > 1024px

## Elevation & Depth

This design system avoids traditional drop shadows. Instead, depth is conveyed through **Light Emission and Glass-morphism**:

- **Tiers of Depth:**
  - **Level 0 (Background):** Solid #050508.
  - **Level 1 (Cards):** Glass-morphic surfaces with a 1px border (`rgba(255,255,255,0.1)`). 20px Backdrop Blur.
  - **Level 2 (Modals/Overlays):** Increased glass opacity with a Cyan outer glow (`0 0 20px rgba(34, 227, 255, 0.2)`).
- **Glow Effects:** Critical elements use `box-shadow` or `filter: drop-shadow` with the Primary Cyan or Secondary Magenta colors to simulate neon tubes. The glow should be soft and diffused, never harsh.

## Shapes

The shape language is structured and hierarchical to maintain a "built" feel:

- **Containers:** Large sections and screen wrappers use **16px** rounding.
- **Cards:** Recipe cards and ingredient tiles use **12px** rounding.
- **Small Elements:** Buttons, input fields, and tags use **8px** rounding.

This creates a nested visual logic where internal components feel like they "fit" within their parent containers.

## Components

- **Buttons:**
  - **Primary:** Solid Electric Cyan background with #050508 text. Add a `0 0 15px rgba(34, 227, 255, 0.5)` glow.
  - **Secondary:** Ghost style. 1px Cyan border, Cyan text, no background.
- **Cards:** Glass-morphic with 1px border. Background: `rgba(255, 255, 255, 0.03)`. 
- **Input Fields:** Darker background than cards, 1px Cyan border on focus. Text in JetBrains Mono.
- **Chips/Tags:** Small 8px radius pill shapes. Use Magenta for "AI Recommended" or "Spicy" tags.
- **Icons:** Phosphor-style line icons. Stroke weight: 1.5px. Primary Cyan color. 
- **Progress Bars:** Thin Cyan lines. The "active" portion should have a blurred glow trailing the progress head.
- **Glass-morphism Tip:** Ensure contrast ratios for body text remain above 4.5:1 by adjusting the `backdrop-filter: brightness()` if necessary behind text areas.